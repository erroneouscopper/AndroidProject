package team3.phms;

//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.app.Activity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class CurrentList extends Activity {

    private Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_list);
        addItemsTospinner();
        addListnerTospinner();
    }

    private void addListnerTospinner() {

        spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(new OnItemSelectedListener() {

            public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
                // Get the item selected in the Spinner
                String itemSelectedInSpinner = parent.getItemAtPosition(i).toString();
                if(i==1){
                    startActivity(new Intent(CurrentList.this,High_blood_pressure.class));
                }
                else if(i==2){
                    startActivity(new Intent(CurrentList.this,Low_blood_pressure.class));
                }
                else if(i==3){
                    startActivity(new Intent(CurrentList.this,Cholesterol.class));
                }
                else if(i==4){
                    startActivity(new Intent(CurrentList.this,overweight.class));
                }
                else if(i==5){
                    startActivity(new Intent(CurrentList.this,underweight.class));
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }


        });
    }

    public void addItemsTospinner() {
        spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(this,
                R.array.Medications, android.R.layout.simple_spinner_item);

        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spinnerAdapter);
    }
}






