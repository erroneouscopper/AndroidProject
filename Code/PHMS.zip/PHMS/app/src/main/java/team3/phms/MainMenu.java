package team3.phms;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainMenu extends AppCompatActivity {

    Button notes_button;
    Button diet_button;
    Button medButton;
    Button vs_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        // notes button
        notes_button=(Button)findViewById(R.id.notes_button);
        notes_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i= new Intent(MainMenu.this,Notes.class);
                startActivity(i);
            }
        });
        // diet button
        diet_button=(Button)findViewById(R.id.diet_button);
        diet_button.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent x = new Intent(MainMenu.this,Diet.class);
                startActivity(x);
            }
        });

        // medication button
        medButton = (Button) findViewById(R.id.med_button);
        medButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i= new Intent(MainMenu.this,MedicationActivity.class);
                startActivity(i);
            }
        });

        // vital signs
        vs_button = (Button) findViewById(R.id.vs_button);
        vs_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i= new Intent(MainMenu.this,vital_signs.class);
                startActivity(i);

            }
        });

    }

    public void onClick(View view) {
        Intent logout = new Intent(this, LoginActivity.class);
        startActivity(logout);
    }
}
