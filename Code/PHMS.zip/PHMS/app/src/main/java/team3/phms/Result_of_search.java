package team3.phms;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Result_of_search extends AppCompatActivity {

    private Button notifybutton;
    private TextView resView;
    private TextView notifytext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_of_search);

        notifybutton = (Button) findViewById(R.id.notify_button);
        resView = (TextView) findViewById(R.id.resView);
        notifytext = (TextView) findViewById(R.id.notify_text);



        notifybutton=(Button)findViewById(R.id.notify_button);
        notifybutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Doctor has been notified",Toast.LENGTH_LONG).show();
            }
        });
    }

    public void onClick(View view) {
        if (view == notifybutton) {
            Intent notButton = new Intent(this, NotifyActivity.class);
            startActivity(notButton);
        }
    }
}
