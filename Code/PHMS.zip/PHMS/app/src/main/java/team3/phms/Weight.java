package team3.phms;

import android.os.Bundle;
import android.app.Activity;

public class Weight extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight);
    }

}
