package team3.phms;

import android.os.Bundle;
import android.app.Activity;
import android.widget.TextView;

public class glucose_level extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_glucose_level);
    }


}
