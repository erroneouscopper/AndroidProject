package team3.phms;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;

public class vital_signs extends Activity {

    Button gl_button;
    Button w_button;
    Button bl_button;
    Button chl_button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vital_signs);


        gl_button=(Button)findViewById(R.id.gl_button);
        gl_button.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent b = new Intent(vital_signs.this,glucose_level.class);
                startActivity(b);
            }
        });

        w_button=(Button)findViewById(R.id.w_button);
        w_button.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent b = new Intent(vital_signs.this,Weight.class);
                startActivity(b);
            }
        });

        bl_button=(Button)findViewById(R.id.bl_button);
        bl_button.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent b = new Intent(vital_signs.this,Blood_pressure.class);
                startActivity(b);
            }
        });

        chl_button=(Button)findViewById(R.id.chl_button);
        chl_button.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent b = new Intent(vital_signs.this,Cholesterol_vital.class);
                startActivity(b);
            }
        });

    }

}
