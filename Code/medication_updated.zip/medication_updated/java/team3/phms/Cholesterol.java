package team3.phms;

import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Cholesterol extends Activity {

    Button choldocbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cholesterol);

        choldocbutton =(Button)findViewById(R.id.choldocbutton);
        choldocbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Doctor has been notified",Toast.LENGTH_LONG).show();
            }
        });
    }

}
