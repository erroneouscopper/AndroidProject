package team3.phms;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ResultFound extends AppCompatActivity {

    private Button notifybutton1;
    private TextView resView1;
    private TextView notifytext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_found);

        notifybutton1 = (Button) findViewById(R.id.notify_button1);
        resView1 = (TextView) findViewById(R.id.resView1);
        notifytext = (TextView) findViewById(R.id.notify_text);



        notifybutton1=(Button)findViewById(R.id.notify_button1);
        notifybutton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Doctor has been notified",Toast.LENGTH_LONG).show();
            }
        });
    }

    public void onClick(View view) {
        if (view == notifybutton1) {
            Intent notButton = new Intent(this, NotifyActivity.class);
            startActivity(notButton);
        }
    }
}
