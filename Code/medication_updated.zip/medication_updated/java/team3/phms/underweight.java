package team3.phms;

import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class underweight extends Activity {

    Button underdocbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_underweight);


        underdocbutton =(Button)findViewById(R.id.underdocbutton);
        underdocbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Doctor has been notified",Toast.LENGTH_LONG).show();
            }
        });
    }

}
