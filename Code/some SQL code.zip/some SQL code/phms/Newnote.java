package team3.phms;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.GridLayout;

public class Newnote extends AppCompatActivity {

    EditText newnote;
    GridLayout Grid;
    DatabaseHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newnote);
        newnote = (EditText) findViewById(R.id.newnote);
        Grid = (GridLayout) findViewById(R.id.Grid);
        dbHandler = new DatabaseHandler(this, null, null, 1);
        printdb();
    }

    public void savenote(View view){
        NotesList note = new NotesList(newnote.getText().toString());
        dbHandler.addNote(note);
        printdb();
    }
/*
    public void deletenote(View view){
        String input = notename.getText().toString();
        dbHandler.deleteNote(input);
        printdb();
    }
    */
    public void printdb(View view){
        String dbString = dbHandler.dbToString();
        Grid.setText(dbString);
        newnote.setText("");
    }
}
