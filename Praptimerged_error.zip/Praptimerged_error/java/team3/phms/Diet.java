package team3.phms;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;


public class Diet extends Activity {

    Button enterdiet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diet);


        enterdiet=(Button)findViewById(R.id.enterdiet);
        enterdiet.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent b = new Intent(Diet.this,Health_issues.class);
                startActivity(b);
            }
        });

    }
}