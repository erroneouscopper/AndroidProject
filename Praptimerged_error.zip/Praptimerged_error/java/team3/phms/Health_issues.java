package team3.phms;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;
public class Health_issues extends Activity {

    private Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_issues);
        addItemsTospinner();
        addListnerTospinner();

    }

    private void addListnerTospinner() {

        spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(new OnItemSelectedListener() {

            public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
                // Get the item selected in the Spinner
                String itemSelectedInSpinner = parent.getItemAtPosition(i).toString();
                if(i==0){
                    startActivity(new Intent(Health_issues.this,High_blood_pressure.class));
                }
                else if(i==1){
                    startActivity(new Intent(Health_issues.this,Low_blood_pressure.class));
                }
                else if(i==2){
                    startActivity(new Intent(Health_issues.this,Cholestrol.class));
                }
                else if(i==3){
                    startActivity(new Intent(Health_issues.this,overweight.class));
                }
                else if(i==4){
                    startActivity(new Intent(Health_issues.this,underweight.class));
                }
            }


            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO maybe add something here later
            }
        });
    }

    public void addItemsTospinner() {
        spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(this,
                R.array.health_issues, android.R.layout.simple_spinner_item);

        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spinnerAdapter);
    }


}
