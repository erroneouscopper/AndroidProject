package team3.phms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MainMenu extends AppCompatActivity {

    Button logoutButton;
    Button medButton;
    Button diet_button;
    Button vitSigButton;
    Button notes_button;
    ImageButton searchButton;
    ImageButton settingButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        logoutButton = (Button) findViewById(R.id.log_out_button);
        medButton = (Button) findViewById(R.id.med_button);
        diet_button = (Button) findViewById(R.id.diet_button);
        vitSigButton = (Button) findViewById(R.id.vs_button);
        notes_button = (Button) findViewById(R.id.notes_button);
        searchButton = (ImageButton) findViewById(R.id.search_button);
        settingButton = (ImageButton) findViewById(R.id.settings_button);
    }

    public void onClick(View view) {
        if (view == logoutButton) {
            Intent logout = new Intent(this, LoginActivity.class);
            startActivity(logout);
        } else if (view == medButton) {
            Intent medication = new Intent(this, MedicationActivity.class);
            startActivity(medication);
        } else if (view == diet_button) {
            Intent x = new Intent(MainMenu.this,Diet.class);
            startActivity(x);
        } else if (view == vitSigButton) {
            Intent medication = new Intent(this, MedicationActivity.class);
            startActivity(medication);
        } else if (view == notes_button) {
            Intent i= new Intent(MainMenu.this,Notes.class);
            startActivity(i);
        } else if (view == searchButton) {
            Intent medication = new Intent(this, MedicationActivity.class);
            startActivity(medication);
        } else if (view == settingButton) {
            Intent medication = new Intent(this, MedicationActivity.class);
            startActivity(medication);
        }
    }
}
