package team3.phms;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MedicationActivity extends AppCompatActivity {

    private Button searchMedButton;
    private Button cancelButton;
    private TextView medText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medication);

        medText = (TextView) findViewById(R.id.med_Text);
        searchMedButton = (Button) findViewById(R.id.search_med_Button);
        cancelButton = (Button) findViewById(R.id.cancel_button);

    }

    public void onClick(View view) {
        if (view == cancelButton) {
            Intent mainmenu = new Intent(this, MainMenu.class);
            startActivity(mainmenu);
        }
        if(view == searchMedButton) {
            if (medText.getText().length() == 0) {
                medText.setHintTextColor(Color.RED);
            }
            else {
                //search the medText in Database.
                //if found then go to next activity
                //see if the medication has any side effects
                //else if not found then go to create medication activity
                Intent search_button = new Intent(this, Result_of_search.class);
                startActivity(search_button);




            }
        }
    }
}
