package team3.phms;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;

public class Notes extends Activity {

    Button addnote;
    Button updatenote;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);
        addnote=(Button)findViewById(R.id.addnote); //add note
        addnote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent but1= new Intent(Notes.this,Newnote.class);
                startActivity(but1);
            }

        });


        updatenote=(Button)findViewById(R.id.updatenote);  //update note
        updatenote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent but2= new Intent(Notes.this,Updatenote.class);
                startActivity(but2);
            }

        });
    }

}


